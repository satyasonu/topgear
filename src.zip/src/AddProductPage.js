import React from 'react';
import { withRouter } from 'react-router-dom';
import ProductForm from './ProductForm';

class AddProductPage extends React.Component {
    constructor(props) {
      super(props);
      this.saveProduct = this.saveProduct.bind(this);
    }

    saveProduct(product) {  
        this.props.history.push('/product');     
    }

    render() {
        return (              
            <ProductForm onSubmit={this.saveProduct} />
        );
    }
}

export default withRouter(AddProductPage);
