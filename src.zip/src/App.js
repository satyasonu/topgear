import React from 'react';
import { BrowserRouter as Router, Route, Switch, NavLink} from 'react-router-dom';
import AllProductsPage from './AllProductsPage';
import AddProductPage from './AddProductPage';
import ProductDetailPage from './ProductDetailPage';

class Links extends React.Component {
  render() {
    return (
      <nav>
        <NavLink exact activeClassName="active" to="/">About</NavLink>
        <NavLink exact activeClassName="active" to="/product">Products</NavLink>
      </nav>
    );
  }
}

export default class App extends React.Component {
  render() {
      return (
        <Router>
          <div>
            <Links/>
            <Switch>   
              <React.Fragment>          
                 <Route exact path="/" render={() => <h1>About: This application provides information about the products</h1> } />
                 <Route exact path="/product" component={AllProductsPage} />
                 <Route path="/product/:productname" component={ProductDetailPage} />
                 <br/>     
                 <React.Fragment>           
                    <Route exact path="/addProduct" component={AddProductPage} />
                 </React.Fragment>   
              </React.Fragment>              
            </Switch>
          </div>
        </Router>
      );
  }
}
