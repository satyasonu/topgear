import React from 'react';
import { withRouter } from 'react-router-dom';

class Product extends React.Component {
  show  = () => {
    const path = `/product/${this.props.productname}`;
    const r = window.confirm("Are you sure you want to view the details ?");
    if (r === true){     
      this.props.history.push(path);
    }
  }
  render() {   
    return (
      <tr>
        <td onClick={() => this.show()}>{this.props.productname}</td>
        <td>{this.props.quantity}</td>
        <td>{this.props.price}</td>
      </tr>
    );
  }
}


export default withRouter(Product);