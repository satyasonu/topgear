import React from 'react';
import { Link } from 'react-router-dom';

export default class ProductDetail extends React.Component {
  render() {
    return (
      <div>
        <h1>Products List</h1>
        <h3> Product Name: {this.props.match.params.productname}</h3>
        <Link to="/product">Back</Link>
      </div>
    );
  }
}
