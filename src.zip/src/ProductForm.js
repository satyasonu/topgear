import React from 'react'
import { withFormik, Field, Form } from 'formik'
import * as Yup from 'yup'
import ProductActions from './actions/ProductActions';

const ProductForm = ({errors, touched, isSubmitting,handleSubmit}) => (
    <div>
        <h1>Add Product</h1>
        <Form >
            <div>
                <Field type="text"
                    name="productname" placeholder="Enter Product Name" />
                {touched.productname && errors.productname && <span style={{ color: 'red' }}>{errors.productname}</span>}
            </div>
            <br/>
            <div>
                <Field type="number"
                    name="quantity" placeholder="Enter Quantity" />
                {touched.quantity && errors.quantity && <span style={{ color: 'red' }}>{errors.quantity}</span>}
            </div>
            <br/>
            <div>
                <Field type="text"
                    name="price" placeholder="Enter Price" />
                {touched.price && errors.price && <span style={{ color: 'red' }}>{errors.price}</span>}
            </div>
            <br/>
            <button type="submit" disabled={isSubmitting} onSubmit={handleSubmit} >Submit</button>
        </Form>
    </div>
)

const FormikProductForm = withFormik({

    mapPropsToValues({productname, quantity,price}) {
        return {
            productname: productname || '',
            quantity: quantity || '',
            price: price || ''
        }
    },

    validationSchema: Yup.object().shape({
        productname: Yup.string().required('Product Name is required'),
        quantity: Yup.string().required('Quantity is required'),
        price: Yup.string().required('Price is required')
    }),

    handleSubmit(values, { resetForm, setSubmitting}) {
        console.log(values); 
        ProductActions.addProduct(values);
        console.log("onsubmit..");
        setTimeout(() => {           
            resetForm()
            setSubmitting(false);
        }, 2000);

    }
})(ProductForm)

export default FormikProductForm