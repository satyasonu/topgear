import React from 'react';
import Product from './Product';

export default class ProductList extends React.Component {
  render() {
    var productNodes = this.props.products.map(product => ( 
      <React.Fragment key={product.id}>
      <Product  productname={product.productname} quantity={product.quantity} price={product.price} >
      </Product>  
      </React.Fragment>    
    ));
    return (  
      <div>
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {productNodes}
          </tbody>
        </table>
      </div>
    );
  }
}
