import Dispatcher from '../dispatcher/Dispatcher';
import ProductApi from '../data/ProductApi';
import * as ActionTypes from '../constants/ActionTypes';

export default class ProductActions {
    static addProduct(product) {
        let newproduct = ProductApi.saveProduct(product);
        console.log("Dispatching Add Product");
        Dispatcher.dispatch({
            actionType: ActionTypes.ADD_PRODUCT, // type
            product: product  // payload
        });
    }
}
