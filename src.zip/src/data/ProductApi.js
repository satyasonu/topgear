import axios from 'axios';

export default class ProductApi {
	static getAllProducts(cb) {
		axios.get('http://localhost:4000/products')
			.then(response => cb(response.data))
			.catch(error => { throw error });
	}
	
	static saveProduct(product) {
		axios.post('http://localhost:4000/products',product)
            .then(res => {
				console.log(res);
			    console.log(res.data);
		    })
		     .catch(function (error) {
			    console.log(error);
			});
	}

}
